using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class SceneBackScript : MonoBehaviour
{
    // Update is called once per frame
    /*
    private void Start()
    {
        var items = FindObjectOfType<playerEq>().items;



        for (int i = 0; i < items.Length; i++)
        {
            if (items[i] != 0)
            {

            }

        }
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
        }
    }
    */
}
