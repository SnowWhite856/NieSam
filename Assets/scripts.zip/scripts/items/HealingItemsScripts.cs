using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealingItemsScripts : itemsClass
{
    public float healing;
    public float healingSpeed;
    public float castingTime;
}
