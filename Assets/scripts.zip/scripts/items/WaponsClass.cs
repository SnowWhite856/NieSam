using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaponsClass : itemsClass
{
    public int attackDmg;
    public int ablilityDmg;
    public float atackSpeed;
    public int manaCost;
    public string rarity;
}
