using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class itemsClass : MonoBehaviour
{
    public string name;
    public bool stack;
    public int stackLimit;
    public string Description;
    public Image spriteImage;
}
