using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class EquipBtnScript : MonoBehaviour
{
    public Button myButton;
    public TextMeshProUGUI itemDescription;
    public TextMeshProUGUI WaponSlot;
    public TextMeshProUGUI WaponSlot2;
    public TextMeshProUGUI HelmetSlot;
    public TextMeshProUGUI PlateSlot;
    public TextMeshProUGUI BootsSlot;


    private GameObject toEquip;

    public void EquipItemClick()
    {
        var item = FindObjectOfType<EqScipt>().item;
        foreach (var findItem in item)
        {
            if (findItem.GetComponent<itemsClass>().Description == itemDescription.text)
            {
                toEquip = findItem;
                break;
            }
        }


        switch (toEquip.tag)
        {
            case "wapon":
                if (WaponSlot.text != "")
                {
                    var pastWapon = FindObjectOfType<EqScipt>().currentWapon;
                    FindObjectOfType<EqScipt>().item.Add(pastWapon);
                }
                FindObjectOfType<EqScipt>().currentWapon = toEquip;
                FindObjectOfType<EqScipt>().item.Remove(toEquip);
                WaponSlot.text = toEquip.GetComponent<itemsClass>().name;
                break;

            case "wapon2":
                if (WaponSlot2.text != "")
                {
                    var pastWapon = FindObjectOfType<EqScipt>().currentWapon2;
                    FindObjectOfType<EqScipt>().item.Add(pastWapon);
                }
                FindObjectOfType<EqScipt>().currentWapon2 = toEquip;
                FindObjectOfType<EqScipt>().item.Remove(toEquip);
                WaponSlot2.text = toEquip.GetComponent<itemsClass>().name;
                break;

            case "helmet":
                if (HelmetSlot.text != "")
                {
                    var pastHelmet = FindObjectOfType<EqScipt>().currentHelmet;
                    FindObjectOfType<EqScipt>().item.Add(pastHelmet);
                }
                FindObjectOfType<EqScipt>().currentHelmet = toEquip;
                FindObjectOfType<EqScipt>().item.Remove(toEquip);
                HelmetSlot.text = toEquip.GetComponent<itemsClass>().name;
                break;

            case "plate":
                if (PlateSlot.text != "")
                {
                    var pastPlate = FindObjectOfType<EqScipt>().currentPlate;
                    FindObjectOfType<EqScipt>().item.Add(pastPlate);
                }
                FindObjectOfType<EqScipt>().currentPlate = toEquip;
                FindObjectOfType<EqScipt>().item.Remove(toEquip);
                PlateSlot.text = toEquip.GetComponent<itemsClass>().name;
                break;

            case "boots":
                if (BootsSlot.text != "")
                {
                    var pastBoots = FindObjectOfType<EqScipt>().currentBoots;
                    FindObjectOfType<EqScipt>().item.Add(pastBoots);
                }
                FindObjectOfType<EqScipt>().currentBoots = toEquip;
                FindObjectOfType<EqScipt>().item.Remove(toEquip);
                BootsSlot.text = toEquip.GetComponent<itemsClass>().name;
                break;
        }

        FindObjectOfType<playerEq>().deleteUI();
        FindObjectOfType<playerEq>().addItems();
        itemDescription.text = "";
        FindObjectOfType<ShowItemBtn>().itemRarity.text = "";
        toEquip = null;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            EquipItemClick();
        }
    }

    private void Awake()
    {
        myButton.onClick.AddListener(EquipItemClick);
    }
}
